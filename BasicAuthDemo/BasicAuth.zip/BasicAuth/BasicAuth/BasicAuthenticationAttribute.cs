﻿using System.Net;
using System.Security.Principal;
using System.Text;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace BasicAuth.BasicAuth
{
    public class BasicAuthenticationAttribute : AuthorizationFilterAttribute
    {
        //private const string Realm = "My Realm";
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            if (actionContext.Request.Headers.Authorization == null)
            {
                actionContext.Response = actionContext.Request.CreateErrorResponse(HttpStatusCode.Unauthorized, "login failed!");
            }
            else
            {
                string authToken = actionContext.Request.Headers.Authorization.Parameter;
                // username:password base64 encoded.
                //admin:admin@123
                string decodedAuthToken = Encoding.UTF8.GetString(Convert.FromBase64String(authToken));

                string[] usernamePass = decodedAuthToken.Split(':');
                string username = usernamePass[0];
                string password = usernamePass[1];

                if (ValidateUser.Login(username, password))
                {
                    Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity(username), null);
                }
                else
                {
                    actionContext.Response = actionContext.Request.CreateErrorResponse(HttpStatusCode.Unauthorized, "login failed!");
                }
            }
           
        }
    }
}
